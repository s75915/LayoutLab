package com.example.layoutlab

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ChallengeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layoutResId = intent.getIntExtra("LAYOUT_ID", R.layout.activity_challenge_exercise1)
        setContentView(layoutResId)
    }
}