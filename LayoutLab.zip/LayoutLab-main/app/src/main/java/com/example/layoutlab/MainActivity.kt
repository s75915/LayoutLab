package com.example.layoutlab

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.layoutlab.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Existing exercises (preserved)
        binding.btnLinear.setOnClickListener { open(LinearActivity::class.java) }
        binding.btnRelative.setOnClickListener { open(RelativeActivity::class.java) }
        binding.btnConstraint.setOnClickListener { open(ConstraintActivity::class.java) }
        binding.btnFrame.setOnClickListener { open(FrameActivity::class.java) }
        binding.btnTable.setOnClickListener { open(TableActivity::class.java) }
        binding.btnRecycler.setOnClickListener { open(RecyclerActivity::class.java) }

        // New Challenge Exercises 1 to 6
        binding.btnChallenge1.setOnClickListener { openChallenge(R.layout.activity_challenge_exercise1) }
        binding.btnChallenge2.setOnClickListener { openChallenge(R.layout.activity_challenge_exercise2) }
        binding.btnChallenge3.setOnClickListener { openChallenge(R.layout.activity_challenge_exercise3) }
        binding.btnChallenge4.setOnClickListener { openChallenge(R.layout.activity_challenge_exercise4) }
        binding.btnChallenge5.setOnClickListener { openChallenge(R.layout.activity_challenge_exercise5) }
        binding.btnChallenge6.setOnClickListener { openChallenge(R.layout.activity_challenge_exercise6) }
    }

    private fun open(target: Class<*>) = startActivity(Intent(this, target))

    private fun openChallenge(layoutId: Int) {
        val intent = Intent(this, ChallengeActivity::class.java)
        intent.putExtra("LAYOUT_ID", layoutId)
        startActivity(intent)
    }
}